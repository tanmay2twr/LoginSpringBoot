package com.Wipro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
